/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.27-MariaDB, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: mailservice
-- ------------------------------------------------------
-- Server version	10.5.27-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `App`
--

DROP TABLE IF EXISTS `App`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `App` (
  `id` varchar(191) NOT NULL,
  `tenantId` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `clientId` varchar(191) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `clientSecret` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `App_clientId_key` (`clientId`),
  KEY `App_tenantId_fkey` (`tenantId`),
  CONSTRAINT `App_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `Tenant` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `App`
--

LOCK TABLES `App` WRITE;
/*!40000 ALTER TABLE `App` DISABLE KEYS */;
INSERT INTO `App` VALUES ('acme-app','cmfc89dug0000j6fb1cury7v5','ACME App','acme-client','2025-09-12 00:00:00.000',NULL),('robs-world-app','robs-world-tenant','Robs World App','robs-world-client','2025-09-12 00:00:00.000',NULL);
/*!40000 ALTER TABLE `App` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EmailJob`
--

DROP TABLE IF EXISTS `EmailJob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EmailJob` (
  `id` varchar(191) NOT NULL,
  `jobId` varchar(20) DEFAULT NULL,
  `groupId` varchar(20) DEFAULT NULL,
  `appId` varchar(191) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `scheduledAt` datetime DEFAULT NULL,
  `startedAt` datetime DEFAULT NULL,
  `completedAt` datetime DEFAULT NULL,
  `failedAt` datetime DEFAULT NULL,
  `lastError` text DEFAULT NULL,
  `attemptCount` int(11) DEFAULT 0,
  `maxAttempts` int(11) DEFAULT 3,
  `subject` varchar(128) DEFAULT NULL,
  `senderName` varchar(64) DEFAULT NULL,
  `senderEmail` varchar(64) DEFAULT NULL,
  `host` varchar(64) DEFAULT NULL,
  `username` varchar(64) DEFAULT NULL,
  `recipients` mediumtext DEFAULT NULL,
  `message` mediumtext DEFAULT NULL,
  `createdAt` datetime DEFAULT current_timestamp(),
  `updatedAt` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `jobId` (`jobId`),
  KEY `idx_app_status` (`appId`,`status`),
  KEY `idx_created` (`createdAt`),
  KEY `idx_group_status` (`groupId`,`status`),
  KEY `idx_status_scheduled` (`status`,`scheduledAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EmailJob`
--

LOCK TABLES `EmailJob` WRITE;
/*!40000 ALTER TABLE `EmailJob` DISABLE KEYS */;
/*!40000 ALTER TABLE `EmailJob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Event`
--

DROP TABLE IF EXISTS `Event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Event` (
  `id` varchar(191) NOT NULL,
  `recipientId` varchar(191) DEFAULT NULL,
  `groupId` varchar(191) DEFAULT NULL,
  `type` varchar(191) NOT NULL,
  `occurredAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `Event_type_idx` (`type`),
  KEY `Event_recipientId_fkey` (`recipientId`),
  KEY `Event_groupId_idx` (`groupId`),
  CONSTRAINT `Event_groupId_fkey` FOREIGN KEY (`groupId`) REFERENCES `MessageGroup` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Event_recipientId_fkey` FOREIGN KEY (`recipientId`) REFERENCES `Recipient` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Event`
--

LOCK TABLES `Event` WRITE;
/*!40000 ALTER TABLE `Event` DISABLE KEYS */;
/*!40000 ALTER TABLE `Event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Maillog`
--

DROP TABLE IF EXISTS `Maillog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Maillog` (
  `id` varchar(191) NOT NULL,
  `messageId` varchar(255) DEFAULT NULL,
  `groupId` varchar(20) DEFAULT NULL,
  `appId` varchar(191) DEFAULT NULL,
  `sent` datetime DEFAULT current_timestamp(),
  `subject` varchar(128) DEFAULT NULL,
  `senderName` varchar(64) DEFAULT NULL,
  `senderEmail` varchar(64) DEFAULT NULL,
  `host` varchar(64) DEFAULT NULL,
  `username` varchar(64) DEFAULT NULL,
  `recipients` mediumtext DEFAULT NULL,
  `message` mediumtext DEFAULT NULL,
  `opened` datetime DEFAULT NULL,
  `createdAt` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `messageId` (`messageId`),
  KEY `idx_appId_sent` (`appId`,`sent`),
  KEY `idx_groupId` (`groupId`),
  KEY `idx_messageId` (`messageId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Maillog`
--

LOCK TABLES `Maillog` WRITE;
/*!40000 ALTER TABLE `Maillog` DISABLE KEYS */;
/*!40000 ALTER TABLE `Maillog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Message`
--

DROP TABLE IF EXISTS `Message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Message` (
  `id` varchar(191) NOT NULL,
  `recipientId` varchar(191) NOT NULL,
  `providerId` varchar(191) DEFAULT NULL,
  `sentAt` datetime(3) DEFAULT NULL,
  `openedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `attemptCount` int(11) NOT NULL DEFAULT 1,
  `lastError` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Message_recipientId_fkey` (`recipientId`),
  CONSTRAINT `Message_recipientId_fkey` FOREIGN KEY (`recipientId`) REFERENCES `Recipient` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Message`
--

LOCK TABLES `Message` WRITE;
/*!40000 ALTER TABLE `Message` DISABLE KEYS */;
/*!40000 ALTER TABLE `Message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MessageGroup`
--

DROP TABLE IF EXISTS `MessageGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MessageGroup` (
  `id` varchar(191) NOT NULL,
  `tenantId` varchar(191) NOT NULL,
  `appId` varchar(191) NOT NULL,
  `templateId` varchar(191) DEFAULT NULL,
  `subject` varchar(191) NOT NULL,
  `bodyOverrideHtml` varchar(191) DEFAULT NULL,
  `bodyOverrideText` varchar(191) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'draft',
  `scheduledAt` datetime(3) DEFAULT NULL,
  `startedAt` datetime(3) DEFAULT NULL,
  `completedAt` datetime(3) DEFAULT NULL,
  `createdBy` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `totalRecipients` int(11) NOT NULL DEFAULT 0,
  `processedRecipients` int(11) NOT NULL DEFAULT 0,
  `sentCount` int(11) NOT NULL DEFAULT 0,
  `failedCount` int(11) NOT NULL DEFAULT 0,
  `canceledAt` datetime(3) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `MessageGroup_tenantId_fkey` (`tenantId`),
  KEY `MessageGroup_templateId_fkey` (`templateId`),
  KEY `MessageGroup_appId_fkey` (`appId`),
  CONSTRAINT `MessageGroup_appId_fkey` FOREIGN KEY (`appId`) REFERENCES `App` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `MessageGroup_templateId_fkey` FOREIGN KEY (`templateId`) REFERENCES `Template` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `MessageGroup_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `Tenant` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MessageGroup`
--

LOCK TABLES `MessageGroup` WRITE;
/*!40000 ALTER TABLE `MessageGroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `MessageGroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Recipient`
--

DROP TABLE IF EXISTS `Recipient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Recipient` (
  `id` varchar(191) NOT NULL,
  `groupId` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`context`)),
  `status` varchar(191) NOT NULL DEFAULT 'pending',
  `lastError` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `renderedSubject` varchar(191) DEFAULT NULL,
  `renderedHtml` varchar(191) DEFAULT NULL,
  `renderedText` varchar(191) DEFAULT NULL,
  `failedAttempts` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Recipient_groupId_email_key` (`groupId`,`email`),
  KEY `Recipient_groupId_status_idx` (`groupId`,`status`),
  CONSTRAINT `Recipient_groupId_fkey` FOREIGN KEY (`groupId`) REFERENCES `MessageGroup` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Recipient`
--

LOCK TABLES `Recipient` WRITE;
/*!40000 ALTER TABLE `Recipient` DISABLE KEYS */;
/*!40000 ALTER TABLE `Recipient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SmsConfig`
--

DROP TABLE IF EXISTS `SmsConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SmsConfig` (
  `id` varchar(191) NOT NULL,
  `scope` enum('GLOBAL','TENANT','APP') NOT NULL,
  `tenantId` varchar(191) DEFAULT NULL,
  `appId` varchar(191) DEFAULT NULL,
  `sid` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `fromNumber` varchar(191) NOT NULL,
  `fallbackTo` varchar(191) DEFAULT NULL,
  `serviceSid` varchar(191) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `createdBy` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `SmsConfig_scope_tenantId_appId_idx` (`scope`,`tenantId`,`appId`),
  KEY `SmsConfig_scope_isActive_idx` (`scope`,`isActive`),
  KEY `SmsConfig_tenantId_fkey` (`tenantId`),
  KEY `SmsConfig_appId_fkey` (`appId`),
  CONSTRAINT `SmsConfig_appId_fkey` FOREIGN KEY (`appId`) REFERENCES `App` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `SmsConfig_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `Tenant` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SmsConfig`
--

LOCK TABLES `SmsConfig` WRITE;
/*!40000 ALTER TABLE `SmsConfig` DISABLE KEYS */;
/*!40000 ALTER TABLE `SmsConfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SmtpConfig`
--

DROP TABLE IF EXISTS `SmtpConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SmtpConfig` (
  `id` varchar(191) NOT NULL,
  `scope` enum('GLOBAL','TENANT','APP') NOT NULL,
  `tenantId` varchar(191) DEFAULT NULL,
  `appId` varchar(191) DEFAULT NULL,
  `host` varchar(191) NOT NULL,
  `port` int(11) NOT NULL DEFAULT 587,
  `secure` tinyint(1) NOT NULL DEFAULT 0,
  `user` varchar(191) DEFAULT NULL,
  `pass` varchar(191) DEFAULT NULL,
  `fromAddress` varchar(191) DEFAULT NULL,
  `fromName` varchar(191) DEFAULT NULL,
  `service` varchar(191) NOT NULL DEFAULT 'smtp',
  `awsRegion` varchar(191) DEFAULT NULL,
  `awsAccessKey` varchar(191) DEFAULT NULL,
  `awsSecretKey` varchar(191) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `createdBy` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `SmtpConfig_scope_tenantId_appId_idx` (`scope`,`tenantId`,`appId`),
  KEY `SmtpConfig_tenantId_fkey` (`tenantId`),
  KEY `SmtpConfig_scope_isActive_idx` (`scope`,`isActive`),
  KEY `SmtpConfig_appId_fkey` (`appId`),
  CONSTRAINT `SmtpConfig_appId_fkey` FOREIGN KEY (`appId`) REFERENCES `App` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `SmtpConfig_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `Tenant` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SmtpConfig`
--

LOCK TABLES `SmtpConfig` WRITE;
/*!40000 ALTER TABLE `SmtpConfig` DISABLE KEYS */;
INSERT INTO `SmtpConfig` VALUES ('smtp_acme','TENANT','cmfc89dug0000j6fb1cury7v5',NULL,'localhost',1025,0,'','','test@acme.com','ACME Corporation','smtp',NULL,NULL,NULL,1,'2025-09-12 00:00:00.000','0000-00-00 00:00:00.000',NULL),('smtp_robs_world','TENANT','robs-world-tenant',NULL,'localhost',1025,0,'','','test@robsworld.com','Robs World','smtp',NULL,NULL,NULL,1,'2025-09-12 00:00:00.000','0000-00-00 00:00:00.000',NULL);
/*!40000 ALTER TABLE `SmtpConfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Suppression`
--

DROP TABLE IF EXISTS `Suppression`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Suppression` (
  `id` varchar(191) NOT NULL,
  `tenantId` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `reason` varchar(191) DEFAULT NULL,
  `addedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `Suppression_tenantId_email_idx` (`tenantId`,`email`),
  CONSTRAINT `Suppression_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `Tenant` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Suppression`
--

LOCK TABLES `Suppression` WRITE;
/*!40000 ALTER TABLE `Suppression` DISABLE KEYS */;
/*!40000 ALTER TABLE `Suppression` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Template`
--

DROP TABLE IF EXISTS `Template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Template` (
  `id` varchar(191) NOT NULL,
  `version` int(11) NOT NULL,
  `subject` mediumtext DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  `appId` varchar(191) NOT NULL DEFAULT 'retreehawaii',
  `content` mediumtext DEFAULT NULL,
  `title` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Template`
--

LOCK TABLES `Template` WRITE;
/*!40000 ALTER TABLE `Template` DISABLE KEYS */;
/*!40000 ALTER TABLE `Template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tenant`
--

DROP TABLE IF EXISTS `Tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tenant` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'active',
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tenant`
--

LOCK TABLES `Tenant` WRITE;
/*!40000 ALTER TABLE `Tenant` DISABLE KEYS */;
INSERT INTO `Tenant` VALUES ('cmfc3o60i001uhzacbm7d8qn9','Robs World','active','2025-09-12 00:00:00.000'),('cmfc89dug0000j6fb1cury7v5','ACME Corporation','active','2025-09-12 00:00:00.000'),('robs-world-tenant','Robs World Tenant','active','2025-09-12 00:00:00.000'),('test-tenant-1','Test Tenant 1','active','2025-09-12 00:00:00.000'),('test-tenant-2','Test Tenant 2','active','2025-09-12 00:00:00.000');
/*!40000 ALTER TABLE `Tenant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) NOT NULL,
  `checksum` varchar(64) NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) NOT NULL,
  `logs` text DEFAULT NULL,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `applied_steps_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('63dd21d8-2796-433c-972c-137a7bd7a3ca','e09d5894d5818b990172a617975c0b2ff9536b563a5219ff1cf96337271acc29','2025-09-20 09:21:56.628','20240908_0_init',NULL,NULL,'2025-09-20 09:21:56.606',1),('e7d568eb-02dd-435c-babb-aa054f9a969a','1c3aeba8f2b1d9bc519f4c1be938c82f6035277982dc1aff32547f24c9754eee','2025-09-20 09:32:49.000','20250918183728_add_sms_config','A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20250918183728_add_sms_config\n\nDatabase error code: 1146\n\nDatabase error:\nTable \'mailservice._SmsConfigScope\' doesn\'t exist\n\nPlease check the query number 1 from the migration file.\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name=\"20250918183728_add_sms_config\"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name=\"20250918183728_add_sms_config\"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:226',NULL,'2025-09-20 09:21:56.763',0),('f338c543-b9c2-438f-92b4-0e29fd1e1fb4','b20438001d07b4ec769a6b81160bcd60f336a50741d7e6699406117f66d88bd1','2025-09-20 09:21:56.762','20250912005602_add_smtp_configs',NULL,NULL,'2025-09-20 09:21:56.628',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mailservice'
--

--
-- Dumping routines for database 'mailservice'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-20  7:35:33
